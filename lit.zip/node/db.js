/* This is the file where we are going to place our database connections.*/
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/nodewebappdb');